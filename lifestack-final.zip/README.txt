SETUP STRIPE + DELIVERY:

1. Create Stripe account
2. Install stripe:
   npm install stripe

3. Create API route for checkout session

4. Use Stripe Checkout

5. After payment:
   - redirect to success page
   - show download links OR email via SendGrid

RECOMMENDED:
- Use Firebase or Supabase for storing orders
- Store PDFs in cloud storage

