'use client';
import { useState } from 'react';

const products = Array.from({length:50},(_,i)=>({
  id:i+1,
  title:`Premium Guide ${i+1}`,
  price:Math.floor(Math.random()*10)+9,
  desc:'Instant download digital product'
}));

export default function Home(){
  const [cart,setCart]=useState([]);
  const [view,setView]=useState('home');

  const add=(p)=>setCart([...cart,p]);
  const total=cart.reduce((a,b)=>a+b.price,0);

  if(view==='checkout'){
    return (
      <div style={{padding:20}}>
        <h1>Secure Checkout</h1>
        {cart.map((c,i)=>(<div key={i}>{c.title} - ${c.price}</div>))}
        <h2>Total: ${total.toFixed(2)}</h2>
        <button onClick={()=>alert('Stripe integration required - see README')}>Pay with Card</button>
        <p>After payment, user receives download link (setup required)</p>
      </div>
    )
  }

  return (
    <div style={{padding:20}}>
      <h1>LifeStack Digital Vault</h1>
      <button onClick={()=>setView('checkout')}>Cart ({cart.length})</button>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
        {products.map(p=>(
          <div key={p.id} style={{border:'1px solid #ccc',padding:10}}>
            <h3>{p.title}</h3>
            <p>{p.desc}</p>
            <p>${p.price}</p>
            <button onClick={()=>add(p)}>Add</button>
          </div>
        ))}
      </div>
    </div>
  )
}
